// Filename - images.js

// Replace src value with ypur image url
const images = [
	{
		id: 1,
		src: "https://static4.abbyy.com/abbyycommedia/28766/ocrsdk-visual-default.jpg",
		alt: "three",
        
	},
	{
		id: 2,
		src: "https://blog.razorpay.in/blog-content/uploads/2019/01/Fraud-Prevention.png",
		alt: "Image 2 ",
	},
    {
		id: 3,
		src: "https://www.idfcfirstbank.com/content/dam/idfcfirstbank/images/blog/beyond-banking/digital-banking-vs-internet-banking-717x404.jpg",
		alt: "Image 2 ",
	},
    {
		id: 4,
		src: "https://www.perfecto.io/sites/default/files/image/2020-07/social-blog-banking-app-test-considerations.jpg" ,
		alt: "Image 2 ",

	},
    {
		id: 5,
		src: "https://img.etimg.com/thumb/width-640,height-480,imgsize-41563,resizemode-75,msid-84727815/markets/bonds/is-investing-in-a-fund-of-funds-better-than-investing-in-a-mutual-fund.jpg",
		alt: "Image 2 ",
	},
	
];
export default images;